const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.post('/submit-data', (req, res) => {
    const { data1, data2, qrData } = req.body;
    console.log('Received data:', data1, data2, qrData);
    res.json({ message: 'Data received successfully' });
    res.json({message: `${data1} ${data2} ${qrData}`})
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
