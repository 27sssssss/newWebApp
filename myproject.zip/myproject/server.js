    const express = require('express');
    const cors = require('cors');
    const axios = require('axios');
    const app = express();
    const HTTP_PORT = process.env.HTTP_PORT || 8000;
    app.use(cors({
        origin: 'https://maxcropdata.com/api', // Или указать конкретные разрешённые домены
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        allowedHeaders: ['Content-Type', 'x-api-key']
    }));
    app.use(express.json());
    
    // прокси для отправки запросов
/*     app.get('/api/workers', async (req, res) => {
        try {
            const response = await axios.get('https://maxcropdata.com/api/workers?mode=1', {
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': '18CFC8D85C5F1E0FE3ABBA608CCF3F75' 
                }
            });
            let serverData = response.data;
            console.log(serverData);
        } catch (error) {
            console.error('Error fetching data:', error.message);
            res.status(500).json({ error: 'Failed to fetch data from Max Crop API' });
        }
    });
     */
    async function connectToApi() {
        try {
            const response = await axios.get('https://maxcropdata.com/api/work_report?mode=0&date=2024-07-05', {
                headers: {
                    'x-api-key': '18CFC8D85C5F1E0FE3ABBA608CCF3F75',
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            });
            console.log('Successfully connected to Max Crop API:'/* , response.data */);
            return true;
        } catch (error) {
            console.error('Failed to connect to Max Crop API:', error.message);
            return false;
        }
    }
    app.get('/api', async (req, res) => {
        try {
            const response = await axios.get('https://maxcropdata.com/api/work_report?mode=0&date=2024-07-05', {
                headers: {
                    'x-api-key': '18CFC8D85C5F1E0FE3ABBA608CCF3F75',
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            });
            res.status(200).json(response.data);
        } catch (error) {
            console.error('Error fetching data:', error.message);
            res.status(500).json({ error: 'Failed to fetch data from Max Crop API' });
        }
    })
    app.get('/api/workers-data', async(req, res) => {
        try {
            const response = await axios.get('https://maxcropdata.com/api/workers?mode=1', {
                headers: {
                    'x-api-key': '18CFC8D85C5F1E0FE3ABBA608CCF3F75',
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            });
            let data = [];
            response.data.forEach(elem => {
                if (elem.id == 26589){
                    data.push(elem);
                }
            });
            res.status(200).json(data);
        } catch (error) {
            console.error('Error fetching data:', error.message);
            res.status(500).json({ error: 'Failed to fetch data from Max Crop API' });
        }
    })
    app.post('/submit-data', (req, res) => {
        const { data1, data2, qrData } = req.body;
        console.log('Received data:', data1, data2, qrData);
        res.json({ message: `Data received successfully: ${data1} ${data2} ${qrData}` });
    });
    app.get('/api/settlements', async(req, res) => {
        try {
            const response = await axios.get('https://maxcropdata.com/api/settlement', {
                headers: {
                    'x-api-key': '18CFC8D85C5F1E0FE3ABBA608CCF3F75',
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            });
            res.status(200).json(response.data);
        } catch (error) {
            console.error('Error fetching data:', error.message);
            res.status(500).json({ error: 'Failed to fetch data from Max Crop API' });
        }
    })

    connectToApi().then((isConnected) => {
        if (isConnected) {
            app.listen(HTTP_PORT, () => {
                console.log('Server is running on port ' + HTTP_PORT);
            });
        } else {
            console.error('Failed to connect to Max Crop API. Server not started.');
            process.exit(1); // Завершаем процесс с ошибкой
        }
    });